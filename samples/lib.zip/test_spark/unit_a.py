def hello():
    print("Hello :)!")
